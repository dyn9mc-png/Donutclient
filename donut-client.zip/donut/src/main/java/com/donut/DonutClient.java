package com.donut;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class DonutClient implements ClientModInitializer {
    private static KeyBinding openGui;

    @Override public void onInitializeClient() {
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.donut.gui", InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_SHIFT, KeyBinding.Category.create(Identifier.of("donut", "main"))));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openGui.wasPressed()) mc.setScreen(new DonutScreen());
            if (mc.world == null || mc.player == null || !mc.isInSingleplayer()) return; // doar single-player
            AmethystFinder.tick(mc);
            RedstoneFinder.tick(mc);
            HumanBuilder.tick(mc);
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS, Identifier.of("donut", "map"), HudMap::render);
        WorldRenderEvents.END_MAIN.register(ChunkOutlineRenderer::render);
    }
}

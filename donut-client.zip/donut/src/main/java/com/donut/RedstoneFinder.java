package com.donut;

import net.minecraft.block.*;
import net.minecraft.client.MinecraftClient;
import net.minecraft.state.property.Properties;
import net.minecraft.world.chunk.WorldChunk;
import java.util.*;

/**
 * Modul 2: pentru fiecare chunk păstrăm setul pozițiilor "active" (powered/lit/power>0).
 * Scor += |diferența simetrică| între scanări = numărul de flip-uri de stare.
 */
public final class RedstoneFinder {
    public static final ChunkScores scores = new ChunkScores(0.998);
    private static final Map<Long, Set<Long>> snapshots = new HashMap<>();

    private static boolean isRedstone(BlockState s) {
        Block b = s.getBlock();
        return b instanceof RedstoneWireBlock || b instanceof AbstractRedstoneGateBlock || b instanceof ObserverBlock
            || b instanceof RedstoneLampBlock || b instanceof PistonBlock || b instanceof PistonHeadBlock
            || b instanceof RedstoneTorchBlock || b instanceof DispenserBlock;
    }
    private static boolean active(BlockState s) {
        if (s.contains(Properties.POWERED) && s.get(Properties.POWERED)) return true;
        if (s.contains(Properties.LIT) && s.get(Properties.LIT)) return true;
        if (s.contains(Properties.EXTENDED) && s.get(Properties.EXTENDED)) return true;
        return s.contains(Properties.POWER) && s.get(Properties.POWER) > 0;
    }

    public static void tick(MinecraftClient mc) {
        if (!Settings.redstone) return;
        scores.decay();
        for (WorldChunk c : ChunkScanner.next(mc, Settings.scanPerTick)) {
            Set<Long> now = new HashSet<>();
            ChunkScanner.forEach(c, RedstoneFinder::isRedstone, (pos, st) -> { if (active(st)) now.add(pos.asLong()); });
            Set<Long> prev = snapshots.put(c.getPos().toLong(), now);
            if (prev == null) continue;
            Set<Long> diff = new HashSet<>(now); diff.addAll(prev);
            Set<Long> same = new HashSet<>(now); same.retainAll(prev);
            diff.removeAll(same);
            if (!diff.isEmpty()) scores.add(c.getPos().x, c.getPos().z, diff.size());
        }
    }

    public static List<long[]> primeChunks() {
        List<long[]> out = new ArrayList<>();
        scores.all().forEach((k, v) -> { if (v >= Settings.primeThreshold) out.add(new long[]{k}); });
        return out;
    }
}

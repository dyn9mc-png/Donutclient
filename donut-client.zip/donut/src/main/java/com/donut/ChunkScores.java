package com.donut;

import net.minecraft.util.math.ChunkPos;
import java.util.*;

/** Scoruri per chunk cu decay exponențial (activitatea veche dispare treptat). */
public final class ChunkScores {
    private final Map<Long, Double> map = new HashMap<>();
    private final double decayPerTick;
    public ChunkScores(double decayPerTick) { this.decayPerTick = decayPerTick; }

    public void add(int cx, int cz, double v) { map.merge(ChunkPos.toLong(cx, cz), v, Double::sum); }
    public double get(int cx, int cz) { return map.getOrDefault(ChunkPos.toLong(cx, cz), 0.0); }
    public void decay() { map.replaceAll((k, v) -> v * decayPerTick); map.values().removeIf(v -> v < 0.05); }
    public Map<Long, Double> all() { return map; }
    public void clear() { map.clear(); }
}

package com.donut;

/** Setări globale, modificate din GUI. */
public final class Settings {
    public static boolean amethyst = true, redstone = true, builder = false, hudMap = true, worldBoxes = true;
    public static int scanPerTick = 2;           // câte chunk-uri scanate / tick
    public static double primeThreshold = 40.0;  // scor redstone pentru "prime chunk"
    public static int minDelay = 6, maxDelay = 22; // ticks între plasări (jitter)
    public static int failPercent = 4;           // % misclick-uri simulate
    public static int mapRadius = 8;
    private Settings() {}
}

package com.donut;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.util.math.BlockPos;
import java.util.function.Predicate;

/** Utilitare comune: round-robin peste chunk-urile încărcate + iterare secțiuni. */
public final class ChunkScanner {
    private static int cursor = 0;

    public interface BlockVisitor { void visit(BlockPos pos, BlockState state); }

    /** Returnează următoarele `n` chunk-uri încărcate din jurul jucătorului (round-robin). */
    public static java.util.List<WorldChunk> next(MinecraftClient mc, int n) {
        ClientWorld w = mc.world;
        int r = mc.options.getClampedViewDistance();
        int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
        int side = r * 2 + 1, total = side * side;
        java.util.List<WorldChunk> out = new java.util.ArrayList<>();
        for (int i = 0; i < total && out.size() < n; i++) {
            cursor = (cursor + 1) % total;
            WorldChunk c = w.getChunkManager().getWorldChunk(pcx - r + cursor % side, pcz - r + cursor / side);
            if (c != null) out.add(c);
        }
        return out;
    }

    /** Vizitează doar blocurile care trec filtrul; sare peste secțiunile care nu conțin nimic relevant. */
    public static void forEach(WorldChunk chunk, Predicate<BlockState> filter, BlockVisitor v) {
        ChunkSection[] secs = chunk.getSectionArray();
        BlockPos.Mutable p = new BlockPos.Mutable();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection s = secs[i];
            if (s == null || s.isEmpty() || !s.hasAny(filter)) continue;
            int baseY = chunk.getBottomY() + i * 16;
            for (int y = 0; y < 16; y++) for (int z = 0; z < 16; z++) for (int x = 0; x < 16; x++) {
                BlockState st = s.getBlockState(x, y, z);
                if (filter.test(st)) {
                    p.set(chunk.getPos().getStartX() + x, baseY + y, chunk.getPos().getStartZ() + z);
                    v.visit(p, st);
                }
            }
        }
    }
}

package com.donut;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

/** Mini-hartă 2D de chunk-uri: mov = ametist, roșu = redstone, contur auriu = prime chunk. */
public final class HudMap {
    public static void render(DrawContext ctx, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!Settings.hudMap || mc.player == null || mc.options.hudHidden) return;
        int r = Settings.mapRadius, cell = 6, side = (r * 2 + 1) * cell;
        int x0 = ctx.getScaledWindowWidth() - side - 8, y0 = 8;
        ctx.fill(x0 - 2, y0 - 12, x0 + side + 2, y0 + side + 2, 0xB0140A1E);
        ctx.drawTextWithShadow(mc.textRenderer, "Donut Client", x0, y0 - 10, 0xFFFF8FD0);
        int pcx = mc.player.getChunkPos().x, pcz = mc.player.getChunkPos().z;
        for (int dz = -r; dz <= r; dz++) for (int dx = -r; dx <= r; dx++) {
            int cx = pcx + dx, cz = pcz + dz;
            double a = AmethystFinder.scores.get(cx, cz), rs = RedstoneFinder.scores.get(cx, cz);
            int px = x0 + (dx + r) * cell, py = y0 + (dz + r) * cell;
            ctx.fill(px, py, px + cell - 1, py + cell - 1, 0x40FFFFFF);
            if (a > 0.5) ctx.fill(px, py, px + cell - 1, py + cell - 1, heat(0xB066FF, a / 20.0));
            if (rs > 0.5) ctx.fill(px, py, px + cell - 1, py + cell - 1, heat(0xFF3030, rs / Settings.primeThreshold));
            if (rs >= Settings.primeThreshold) ctx.drawBorder(px, py, cell - 1, cell - 1, 0xFFFFD34D);
        }
        int c = x0 + r * cell;
        ctx.fill(c + 1, y0 + r * cell + 1, c + cell - 2, y0 + r * cell + cell - 2, 0xFFFFFFFF);
    }
    private static int heat(int rgb, double t) {
        int alpha = (int) (60 + 190 * Math.min(1.0, t));
        return (alpha << 24) | rgb;
    }
}

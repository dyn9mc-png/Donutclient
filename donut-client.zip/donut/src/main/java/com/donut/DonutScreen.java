package com.donut;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import java.util.function.*;

/** GUI "Donut Client": panel întunecat, accent roz, toggle-uri + stepper-e. Folosește doar ButtonWidget (stabil între versiuni). */
public final class DonutScreen extends Screen {
    private int px, py; private static final int W = 300, H = 230;
    public DonutScreen() { super(Text.literal("Donut Client")); }

    @Override protected void init() {
        px = (width - W) / 2; py = (height - H) / 2; int y = py + 34;
        toggle(y, "Amethyst & Player Finder", () -> Settings.amethyst, v -> Settings.amethyst = v); y += 24;
        toggle(y, "Redstone Prime Finder", () -> Settings.redstone, v -> Settings.redstone = v); y += 24;
        toggle(y, "Human Auto Builder", () -> Settings.builder, v -> Settings.builder = v); y += 24;
        toggle(y, "HUD Map", () -> Settings.hudMap, v -> Settings.hudMap = v); y += 24;
        toggle(y, "World Boxes", () -> Settings.worldBoxes, v -> Settings.worldBoxes = v); y += 28;
        stepper(y, "Fail %", () -> Settings.failPercent, v -> Settings.failPercent = Math.max(0, Math.min(30, v)), 1, px + 14); 
        stepper(y, "Max delay", () -> Settings.maxDelay, v -> Settings.maxDelay = Math.max(Settings.minDelay + 1, Math.min(80, v)), 2, px + 154);
        y += 24;
        addDrawableChild(ButtonWidget.builder(Text.literal("§dLoad .litematic aici"), b -> HumanBuilder.load(MinecraftClient.getInstance()))
            .dimensions(px + 14, y, W - 28, 20).build());
    }

    private void toggle(int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean()); b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(px + 14, y, W - 28, 20).build());
    }
    private static Text label(String n, boolean on) { return Text.literal((on ? "§a● " : "§7○ ") + "§f" + n); }

    private void stepper(int y, String name, IntSupplier get, IntConsumer set, int step, int x) {
        ButtonWidget[] ref = new ButtonWidget[1];
        ref[0] = ButtonWidget.builder(Text.literal(name + ": " + get.getAsInt()), b -> {
            set.accept(get.getAsInt() + step > 80 || (name.startsWith("Fail") && get.getAsInt() + step > 30) ? 0 : get.getAsInt() + step);
            b.setMessage(Text.literal(name + ": " + get.getAsInt()));
        }).dimensions(x, y, 132, 20).build();
        addDrawableChild(ref[0]);
    }

    @Override public void renderBackground(DrawContext c, int mx, int my, float d) {
        c.fillGradient(0, 0, width, height, 0xC0140A1E, 0xC02A0F2E);
    }
    @Override public void render(DrawContext c, int mx, int my, float d) {
        renderBackground(c, mx, my, d);
        c.fill(px - 2, py - 2, px + W + 2, py + H + 2, 0xFFFF8FD0);           // contur roz
        c.fillGradient(px, py, px + W, py + H, 0xF01B1026, 0xF0301540);       // panou
        c.fill(px, py, px + W, py + 26, 0xFF3B1A4A);                          // header
        c.drawCenteredTextWithShadow(textRenderer, Text.literal("§d§l🍩 DONUT §f§lCLIENT"), px + W / 2, py + 9, 0xFFFFFFFF);
        c.drawTextWithShadow(textRenderer, "Rămase: " + HumanBuilder.remaining() + " blocuri", px + 14, py + H - 12, 0xFFB39DDB);
        super.render(c, mx, my, d);
    }
}

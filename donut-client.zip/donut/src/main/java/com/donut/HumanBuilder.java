package com.donut;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.*;
import java.nio.file.*;
import java.util.*;

/**
 * Modul 3: mașină de stări cu comportament "uman":
 *  PAUSE -> pick -> AIM (rotație cu easing + zgomot) -> WAIT (delay gaussian) -> place
 *  + misclick simulat (% configurabil) urmat de re-aim, + pauze și "verificat inventarul".
 * Funcționează doar în single-player (verificat în DonutClient).
 */
public final class HumanBuilder {
    private enum S { PICK, AIM, WAIT }
    private static final Random rnd = new Random();
    private static Schematic schem;
    private static S state = S.PICK;
    private static BlockPos target, support; private static BlockState wanted; private static Direction face;
    private static Vec3d aimPoint;
    private static int wait, pause, placed, nextBreak = 20;
    public static int remaining() { return schem == null ? 0 : schem.blocks.size(); }

    public static void load(MinecraftClient mc) {
        try {
            Path dir = mc.runDirectory.toPath().resolve("donut/schematics"); Files.createDirectories(dir);
            try (var st = Files.list(dir)) {
                Path f = st.filter(p -> p.toString().endsWith(".litematic")).sorted().findFirst().orElse(null);
                if (f == null) { msg(mc, "Pune un .litematic în " + dir); return; }
                schem = Schematic.loadLitematic(f, mc.player.getBlockPos());
                state = S.PICK; msg(mc, f.getFileName() + ": " + schem.blocks.size() + " blocuri");
            }
        } catch (Exception e) { msg(mc, "Eroare: " + e.getMessage()); }
    }
    private static void msg(MinecraftClient mc, String s) { mc.player.sendMessage(net.minecraft.text.Text.literal("[Donut] " + s), true); }

    public static void tick(MinecraftClient mc) {
        if (!Settings.builder || schem == null || mc.currentScreen != null) return;
        ClientPlayerEntity p = mc.player;
        if (pause > 0) { pause--; p.setYaw(p.getYaw() + (float) rnd.nextGaussian() * 0.05f); return; } // micro-drift

        switch (state) {
            case PICK -> pick(mc);
            case AIM -> {
                Vec3d eye = p.getEyePos(), d = aimPoint.subtract(eye);
                float ty = (float) (MathHelper.atan2(d.z, d.x) * 57.2958) - 90f;
                float tp = (float) -(MathHelper.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 57.2958);
                float dy = MathHelper.wrapDegrees(ty - p.getYaw()), dp = tp - p.getPitch();
                if (Math.abs(dy) < 1.2f && Math.abs(dp) < 1.2f) { wait = jitter(); state = S.WAIT; return; }
                float k = 0.22f + rnd.nextFloat() * 0.1f; // easing: pas proporțional cu eroarea
                p.setYaw(p.getYaw() + MathHelper.clamp(dy * k + (float) rnd.nextGaussian() * 0.25f, -14f, 14f));
                p.setPitch(MathHelper.clamp(p.getPitch() + MathHelper.clamp(dp * k + (float) rnd.nextGaussian() * 0.2f, -10f, 10f), -90f, 90f));
            }
            case WAIT -> {
                if (--wait > 0) return;
                if (rnd.nextInt(100) < Settings.failPercent) { // misclick: țintește pe lângă, apoi corectează
                    aimPoint = aimPoint.add(rnd.nextGaussian() * 0.6, rnd.nextGaussian() * 0.6, rnd.nextGaussian() * 0.6);
                    state = S.AIM; pause = 4 + rnd.nextInt(10);
                    aimPoint = faceCenter(support, face);
                    return;
                }
                BlockHitResult hit = new BlockHitResult(aimPoint, face, support, false);
                mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
                p.swingHand(Hand.MAIN_HAND);
                schem.blocks.remove(target);
                if (++placed >= nextBreak) { // pauză "gândită" + scroll hotbar ca la verificarea inventarului
                    pause = 20 + rnd.nextInt(70); placed = 0; nextBreak = 15 + rnd.nextInt(40);
                    if (rnd.nextBoolean()) p.getInventory().setSelectedSlot(rnd.nextInt(9));
                }
                state = S.PICK;
            }
        }
    }

    private static int jitter() {
        double g = Settings.minDelay + Math.abs(rnd.nextGaussian()) * (Settings.maxDelay - Settings.minDelay) / 2.0;
        return (int) MathHelper.clamp(g, Settings.minDelay, Settings.maxDelay + 10);
    }

    private static void pick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player; Vec3d eye = p.getEyePos();
        BlockPos best = null; double bestScore = Double.MAX_VALUE;
        for (var e : schem.blocks.entrySet()) {
            BlockPos bp = e.getKey();
            if (mc.world.getBlockState(bp).getBlock() == e.getValue().getBlock()) { continue; }
            if (eye.squaredDistanceTo(Vec3d.ofCenter(bp)) > 4.2 * 4.2) continue;
            double sc = bp.getY() * 100 + eye.squaredDistanceTo(Vec3d.ofCenter(bp)); // strat cu strat, apoi cel mai aproape
            if (sc < bestScore && findSupport(mc, bp) != null) { bestScore = sc; best = bp; }
        }
        if (best == null) { pause = 30; return; } // nimic în rază: așteaptă (mută-te manual)
        BlockState want = schem.blocks.get(best);
        if (!selectItem(mc, want)) { schem.blocks.remove(best); return; }
        target = best; wanted = want;
        Direction d = findSupport(mc, best); face = d.getOpposite(); support = best.offset(d);
        aimPoint = faceCenter(support, face).add(rnd.nextDouble() * 0.4 - 0.2, rnd.nextDouble() * 0.4 - 0.2, rnd.nextDouble() * 0.4 - 0.2);
        pause = 2 + rnd.nextInt(5); state = S.AIM;
    }

    private static Direction findSupport(MinecraftClient mc, BlockPos pos) {
        for (Direction d : Direction.values()) {
            BlockState n = mc.world.getBlockState(pos.offset(d));
            if (!n.isAir() && n.getFluidState().isEmpty()) return d;
        }
        return null;
    }
    private static Vec3d faceCenter(BlockPos p, Direction f) { return Vec3d.ofCenter(p).add(f.getOffsetX() * 0.5, f.getOffsetY() * 0.5, f.getOffsetZ() * 0.5); }

    private static boolean selectItem(MinecraftClient mc, BlockState want) {
        var inv = mc.player.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack st = inv.getStack(i);
            if (!st.isEmpty() && st.getItem() == want.getBlock().asItem()) {
                if (inv.getSelectedSlot() != i) { inv.setSelectedSlot(i); pause = 3 + rnd.nextInt(6); }
                return true;
            }
        }
        return mc.player.isCreative() ? false : false; // TODO: caută în inventarul complet și mută în hotbar
    }
}

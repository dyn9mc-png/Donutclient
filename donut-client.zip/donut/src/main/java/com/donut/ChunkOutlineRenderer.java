package com.donut;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import java.util.Map;

/**
 * Randare 3D. ATENȚIE: API-ul de rendering s-a schimbat mult în 1.21.9+.
 * Dacă nu compilează, verifică javadoc-ul WorldRenderEvents din fabric-rendering-v1
 * (eveniment: END_MAIN / AFTER_TRANSLUCENT; metodele din context: matrices(), consumers()).
 */
public final class ChunkOutlineRenderer {
    public static void render(WorldRenderContext ctx) {
        if (!Settings.worldBoxes) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.player == null) return;

        MatrixStack m = ctx.matrices();
        VertexConsumer vc = ctx.consumers().getBuffer(RenderLayer.getLines());
        Vec3d cam = mc.gameRenderer.getCamera().getPos(); // în unele build-uri: getCameraPos()
        float pulse = 0.6f + 0.4f * (float) Math.sin(mc.world.getTime() / 6.0);
        int minY = mc.world.getBottomY(), maxY = mc.world.getTopYInclusive() + 1;

        // Redstone prime chunk: coloană masivă pe toată înălțimea lumii
        for (Map.Entry<Long, Double> e : RedstoneFinder.scores.all().entrySet()) {
            if (e.getValue() < Settings.primeThreshold) continue;
            ChunkPos cp = new ChunkPos(e.getKey());
            VertexRendering.drawBox(m, vc,
                cp.getStartX() - cam.x, minY - cam.y, cp.getStartZ() - cam.z,
                cp.getStartX() + 16 - cam.x, maxY - cam.y, cp.getStartZ() + 16 - cam.z,
                1f, 0.2f * pulse, 0.2f, 1f);
        }
        // Ametist/jucători: placă mov la nivelul jucătorului
        double py = Math.floor(mc.player.getY());
        for (Map.Entry<Long, Double> e : AmethystFinder.scores.all().entrySet()) {
            if (e.getValue() < 8.0) continue;
            ChunkPos cp = new ChunkPos(e.getKey());
            VertexRendering.drawBox(m, vc,
                cp.getStartX() - cam.x, py - cam.y, cp.getStartZ() - cam.z,
                cp.getStartX() + 16 - cam.x, py + 3 - cam.y, cp.getStartZ() + 16 - cam.z,
                0.7f, 0.4f, 1f, 1f);
        }
    }
}

package com.donut;

import net.minecraft.block.*;
import net.minecraft.nbt.*;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import java.nio.file.Path;
import java.util.*;

/** Încărcător minimal .litematic (toate regiunile). Formatul .schematic (Sponge/MCEdit) se adaugă similar. */
public final class Schematic {
    public final Map<BlockPos, BlockState> blocks = new LinkedHashMap<>();

    public static Schematic loadLitematic(Path file, BlockPos anchor) throws Exception {
        Schematic s = new Schematic();
        NbtCompound root = NbtIo.readCompressed(file, NbtSizeTracker.ofUnlimitedBytes());
        NbtCompound regions = root.getCompoundOrEmpty("Regions");
        for (String key : regions.getKeys()) {
            NbtCompound r = regions.getCompoundOrEmpty(key);
            NbtCompound pos = r.getCompoundOrEmpty("Position"), size = r.getCompoundOrEmpty("Size");
            int sx = size.getInt("x", 0), sy = size.getInt("y", 0), sz = size.getInt("z", 0);
            int ox = pos.getInt("x", 0) + (sx < 0 ? sx + 1 : 0);
            int oy = pos.getInt("y", 0) + (sy < 0 ? sy + 1 : 0);
            int oz = pos.getInt("z", 0) + (sz < 0 ? sz + 1 : 0);
            sx = Math.abs(sx); sy = Math.abs(sy); sz = Math.abs(sz);

            NbtList pal = r.getListOrEmpty("BlockStatePalette");
            BlockState[] palette = new BlockState[pal.size()];
            for (int i = 0; i < palette.length; i++) palette[i] = parseState(pal.getCompoundOrEmpty(i));
            long[] data = r.getLongArray("BlockStates").orElse(new long[0]);
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(palette.length - 1));
            long mask = (1L << bits) - 1;

            for (int y = 0; y < sy; y++) for (int z = 0; z < sz; z++) for (int x = 0; x < sx; x++) {
                long idx = ((long) y * sx * sz) + (long) z * sx + x, bit = idx * bits;
                int li = (int) (bit >>> 6), off = (int) (bit & 63);
                long v = data[li] >>> off;
                if (off + bits > 64 && li + 1 < data.length) v |= data[li + 1] << (64 - off);
                BlockState st = palette[(int) (v & mask)];
                if (st.isAir()) continue;
                s.blocks.put(anchor.add(ox + x, oy + y, oz + z), st);
            }
        }
        return s;
    }

    private static BlockState parseState(NbtCompound n) {
        Block b = Registries.BLOCK.get(Identifier.of(n.getString("Name", "minecraft:air")));
        BlockState st = b.getDefaultState();
        NbtCompound props = n.getCompoundOrEmpty("Properties");
        for (String pn : props.getKeys()) {
            Property<?> p = b.getStateManager().getProperty(pn);
            if (p != null) st = with(st, p, props.getString(pn, ""));
        }
        return st;
    }
    private static <T extends Comparable<T>> BlockState with(BlockState s, Property<T> p, String v) {
        return p.parse(v).map(x -> s.with(p, x)).orElse(s);
    }
}

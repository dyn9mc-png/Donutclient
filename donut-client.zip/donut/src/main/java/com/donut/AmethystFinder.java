package com.donut;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import java.util.*;

/**
 * Modul 1: scor = creștere ametist (delta stadii între scanări) + prezență budding
 *          + mișcarea altor jucători în chunk.
 * Notă: în single-player nu există alți jucători; metrica rămâne pentru LAN/world-uri cu NPC-uri.
 */
public final class AmethystFinder {
    public static final ChunkScores scores = new ChunkScores(0.9995);
    private static final Map<Long, Integer> lastStage = new HashMap<>();
    private static final Map<UUID, Vec3d> lastPos = new HashMap<>();

    private static int stage(Block b) {
        if (b == Blocks.SMALL_AMETHYST_BUD) return 1;
        if (b == Blocks.MEDIUM_AMETHYST_BUD) return 2;
        if (b == Blocks.LARGE_AMETHYST_BUD) return 3;
        if (b == Blocks.AMETHYST_CLUSTER) return 4;
        return 0;
    }

    public static void tick(MinecraftClient mc) {
        if (!Settings.amethyst) return;
        scores.decay();

        for (WorldChunk c : ChunkScanner.next(mc, Settings.scanPerTick)) {
            int[] sum = {0}, budding = {0};
            ChunkScanner.forEach(c, s -> s.isOf(Blocks.BUDDING_AMETHYST) || stage(s.getBlock()) > 0, (pos, st) -> {
                if (st.isOf(Blocks.BUDDING_AMETHYST)) budding[0]++; else sum[0] += stage(st.getBlock());
            });
            long key = c.getPos().toLong();
            Integer prev = lastStage.put(key, sum[0]);
            if (prev != null && sum[0] != prev) scores.add(c.getPos().x, c.getPos().z, Math.abs(sum[0] - prev) * 3.0); // creștere/spargere
            if (budding[0] > 0) scores.add(c.getPos().x, c.getPos().z, 0.02 * budding[0]); // prezență (acumulare lentă)
        }

        // Activitatea jucătorilor/entităților: delta de mișcare pe chunk
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player) continue;
            Vec3d now = p.getPos(), old = lastPos.put(p.getUuid(), now);
            if (old != null) scores.add(p.getChunkPos().x, p.getChunkPos().z, now.distanceTo(old) * 0.5 + 0.1);
        }
    }
}
